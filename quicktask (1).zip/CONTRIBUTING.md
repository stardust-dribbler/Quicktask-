# Contributing

Thank you for considering contributing to QuickTask!

1. Fork the repo
2. Create a feature branch
3. Submit a Pull Request

Be sure to run all tests before submitting.