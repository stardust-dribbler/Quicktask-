# Security Policy

If you discover a vulnerability, please report it via email to stardustdribbler@gmail.com.