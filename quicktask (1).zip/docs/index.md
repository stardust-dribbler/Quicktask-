# QuickTask Docs

QuickTask is a simple command-line To-Do application written in Python.

## Commands
- `add <task>` — Add a new task
- `list` — Show all tasks
- `done <number>` — Mark task as done

### Example
```bash
python src/main.py add "Learn Python"
python src/main.py list
```