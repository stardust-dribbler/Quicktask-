import json, os, sys

def load_tasks():
    if not os.path.exists('tasks.json'):
        return []
    with open('tasks.json', 'r') as f:
        return json.load(f)

def save_tasks(tasks):
    with open('tasks.json', 'w') as f:
        json.dump(tasks, f, indent=2)

def add_task(task):
    tasks = load_tasks()
    tasks.append({'task': task, 'done': False})
    save_tasks(tasks)
    print(f'Added: {task}')

def list_tasks():
    tasks = load_tasks()
    if not tasks:
        print('No tasks yet.')
        return
    for i, t in enumerate(tasks, 1):
        status = '✔' if t['done'] else '✖'
        print(f'{i}. [{status}] {t["task"]}')

def mark_done(index):
    tasks = load_tasks()
    try:
        tasks[index-1]['done'] = True
        save_tasks(tasks)
        print(f'Marked task {index} as done.')
    except IndexError:
        print('Invalid task number.')

def main():
    if len(sys.argv) < 2:
        print('Usage: python main.py [add|list|done]')
        return
    command = sys.argv[1]
    if command == 'add' and len(sys.argv) > 2:
        add_task(' '.join(sys.argv[2:]))
    elif command == 'list':
        list_tasks()
    elif command == 'done' and len(sys.argv) == 3:
        mark_done(int(sys.argv[2]))
    else:
        print('Invalid command.')

if __name__ == '__main__':
    main()