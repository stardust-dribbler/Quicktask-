# Contributing to QuickTask

1. Fork the repo
2. Create a new branch
3. Submit a Pull Request
