# QuickTask

A lightweight Python CLI To-Do app — manage your tasks directly from the terminal.

## Features
- Add, list, and delete tasks
- Persistent local storage (JSON)
- Minimal and fast

## Usage
```bash
python src/main.py add "Buy milk"
python src/main.py list
python src/main.py done 1
```

## License
MIT License
