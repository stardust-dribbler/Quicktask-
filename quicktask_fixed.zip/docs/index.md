# QuickTask Docs

QuickTask is a minimal command-line To-Do app in Python.

## Commands
- add <task>
- list
- done <task number>

Example:
```bash
python src/main.py add "Study for exam"
python src/main.py list
```
