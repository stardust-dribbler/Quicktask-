import os, json, src.main as main

def test_add_and_list():
    if os.path.exists('tasks.json'):
        os.remove('tasks.json')
    main.add_task('Test Task')
    tasks = main.load_tasks()
    assert len(tasks) == 1
    assert tasks[0]['task'] == 'Test Task'
